package ca.yorku.eecs4413project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eecs4413projectApplicationTests {

	@Test
	void contextLoads() {
	}

}
